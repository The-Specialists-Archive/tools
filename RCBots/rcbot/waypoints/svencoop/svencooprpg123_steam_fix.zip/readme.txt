------------------------------------------------------------------
Steam Loading error fix for the SvenCoop maps svencooprpg 1 2 & 3
------------------------------------------------------------------

If these maps won't load and kick back to the svencoop main menu and the console (~) shows this error:

Host_Error: ED_LoadFromFile: found  when expecting {

Then here is how to fix it...

First, I read some place that the steam Half-Life beta will fix this, so you could try that, but I don't know for certain that it works?

If you know how to use BSPedit.exe, just remove any extra characters at the bottom of the entity list. The last and only character should be a   }   ,on the last line.

Or you can use ripent.exe with the provided ent files to fix it. Be sure to backup the bsp's first before attempting this...

1. place the ent files in the svencoop/maps folder, ripent.exe should already be there.

2. Bring up the command line editor, for winXP it's start & run then type cmd and enter, a window should pop up.

3. Change the directory (cd) to the svencoop maps folder. To save typing, you can copy & paste the location from the windows address bar if you drill down to the maps folder with explorer. On my install, the whole command line looks like this:

cd C:\Program Files\Steam\SteamApps\common\Half-Life\svencoop\maps

4. To fix the first map type this in the cmd editor:

ripent svencooprpg -import 

You should see the ripent banner with some information, ending with "Reading the mapname.ent", elapsed time and ----- End ripent ----- 

note: the date stamp and size on the map bsp will be changed if all went well...

5. Repeat for the other 2 maps and you are done, the maps should load in steam now...



